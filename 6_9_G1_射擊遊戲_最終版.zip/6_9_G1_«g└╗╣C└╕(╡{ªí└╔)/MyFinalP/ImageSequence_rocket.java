 

public class ImageSequence_rocket extends ImageSequence_enemy{

}
