 

public class ImageSequence_smile extends ImageSequence_enemy{

}
