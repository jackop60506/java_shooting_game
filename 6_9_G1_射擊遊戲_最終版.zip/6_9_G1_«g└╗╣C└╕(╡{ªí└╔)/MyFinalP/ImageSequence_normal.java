 

import java.awt.Image;
import java.util.ArrayList;

public class ImageSequence_normal extends ImageSequence_enemy{
	private static ArrayList<Image> enemy_normal_image_sequence= new ArrayList<Image>();
	private static ArrayList<Image> enemy_normals_image_sequence= new ArrayList<Image>();
	public ImageSequence_normal(){
		
	}
}
