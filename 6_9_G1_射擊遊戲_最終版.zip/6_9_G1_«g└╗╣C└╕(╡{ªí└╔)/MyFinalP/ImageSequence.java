 
import java.awt.Image;

public abstract class ImageSequence {
	protected static String path="pic/";
	protected static String filename=".png";
	//public abstract Image getImage(int i);
	//public abstract Image nextImage();
}
